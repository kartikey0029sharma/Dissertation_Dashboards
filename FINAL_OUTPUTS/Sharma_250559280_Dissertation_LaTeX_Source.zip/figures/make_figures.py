"""Draw every chart and dashboard mock-up used in the dissertation.
Run:  python make_figures.py   (writes PDF files into this folder)
All values are those reported in Chapter 4 and Appendix P of the text.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.ticker
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch
from matplotlib.lines import Line2D

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 8.5,
    "axes.titlesize": 9,
    "axes.labelsize": 8.5,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": 7.5,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "pdf.fonttype": 42,
})

NAVY = "#1F3A5F"
TEAL = "#2A8A7A"
AMBER = "#D9962B"
RED = "#B03A2E"
GREY = "#8A8F96"
LIGHT = "#E9EEF4"
PALE = "#F4F6F8"


def save(fig, name):
    fig.savefig(name, bbox_inches="tight")
    plt.close(fig)
    print("wrote", name)


# ---------------------------------------------------------------------------
# Dashboard mock-ups (Figures 1.1 and 1.2)
# ---------------------------------------------------------------------------
def draw_dashboard(ax, banner=False, callouts=False):
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 62)
    ax.axis("off")
    # frame
    ax.add_patch(Rectangle((0, 0), 100, 62, fc="white", ec="#C9CED6", lw=0.8))
    # header
    ax.add_patch(Rectangle((0, 56), 100, 6, fc=NAVY, ec=NAVY))
    ax.text(2, 59, "Kovai Footwear  |  Store Network Performance", color="white",
            fontsize=8, fontweight="bold", va="center")
    ax.text(64, 59, "Region: All", color="white", fontsize=6.5, va="center")
    ax.text(79, 59, "Period: last 90 days", color="white", fontsize=6.5, va="center")

    y_top = 54
    if banner:
        ax.add_patch(FancyBboxPatch((2, 46.5), 96, 7, boxstyle="round,pad=0.2",
                                    fc="#FCEFEF", ec=RED, lw=1.2))
        ax.text(4, 51.5, "\u26A0  Footfall feed: 3 of 22 counters are not reporting.",
                color=RED, fontsize=7, fontweight="bold", va="center")
        ax.text(5.5, 48.6, "Tiruppur counter offline since 12 May (22 days). "
                "Site Score recomputed on reporting counters only: 87 \u2192 62.",
                color=RED, fontsize=6.2, va="center")
        y_top = 45.5

    # KPI tiles
    tiles = [("NET REVENUE (90 DAYS)", "\u20B918.4 cr", "\u25B2 6.2% vs LY"),
             ("FOOTFALL", "4.21 lakh", "\u25B2 11.0% vs LY"),
             ("CONVERSION RATE", "21.4%", "\u25B2 0.8 pp vs LY"),
             ("SALES PER SQ FT", "\u20B91,240", "\u25B2 4.1% vs LY")]
    x = 2
    for label, val, delta in tiles:
        ax.add_patch(Rectangle((x, y_top - 9), 23, 8.5, fc=PALE, ec="#D8DEE6", lw=0.6))
        ax.text(x + 1, y_top - 1.8, label, fontsize=5.5, color="#4A5563", fontweight="bold")
        ax.text(x + 1, y_top - 5, val, fontsize=10, color=NAVY, fontweight="bold")
        ax.text(x + 1, y_top - 8, delta, fontsize=5.8, color=TEAL)
        x += 24.5

    # shortlist table
    ty = y_top - 12
    ax.text(2, ty, "EXPANSION SHORTLIST \u00B7 by Site Score", fontsize=6,
            color="#4A5563", fontweight="bold")
    ax.text(2, ty - 3.2, "Candidate town", fontsize=5.5, color="#4A5563", fontweight="bold")
    ax.text(22, ty - 3.2, "Site Score", fontsize=5.5, color="#4A5563", fontweight="bold")
    ax.text(33, ty - 3.2, "Action", fontsize=5.5, color="#4A5563", fontweight="bold")
    ax.plot([2, 44], [ty - 4.2, ty - 4.2], color="#D8DEE6", lw=0.6)
    if not banner:
        rows = [("Tiruppur", 87, "Open Q3", TEAL, True),
                ("Salem", 74, "Watch", AMBER, False),
                ("Erode", 71, "Watch", AMBER, False),
                ("Thrissur", 63, "Hold", GREY, False),
                ("Kollam", 58, "Hold", GREY, False)]
    else:
        rows = [("Salem", 74, "Watch", AMBER, False),
                ("Erode", 71, "Watch", AMBER, False),
                ("Thrissur", 63, "Hold", GREY, False),
                ("Tiruppur", 62, "Hold", RED, True),
                ("Kollam", 58, "Hold", GREY, False)]
    ry = ty - 7.2
    for town, score, action, col, hl in rows:
        if hl:
            ax.add_patch(Rectangle((2, ry - 1.4), 42, 3.2,
                                   fc=("#E6F4F1" if not banner else "#FCEFEF"), ec="none"))
        ax.text(3, ry, town, fontsize=6, va="center")
        ax.text(24, ry, str(score), fontsize=6, va="center", fontweight="bold")
        ax.add_patch(FancyBboxPatch((33, ry - 1.1), 9, 2.2, boxstyle="round,pad=0.15",
                                    fc="white", ec=col, lw=0.8))
        ax.text(37.5, ry, action, fontsize=5, ha="center", va="center", color=col,
                fontweight="bold")
        ry -= 3.8

    # bar chart
    bx = 50
    ax.text(bx, ty, "FOOTFALL GROWTH vs LAST YEAR (%)", fontsize=6,
            color="#4A5563", fontweight="bold")
    bars = [("Tiruppur", 18.4), ("Salem", 11.2), ("Erode", 9.6), ("Thrissur", 5.1), ("Kollam", 3.8)]
    by = ty - 5.2
    for i, (town, v) in enumerate(bars):
        ax.text(bx + 8, by, town, fontsize=5.8, ha="right", va="center")
        w = v * 1.9
        stale = banner and town == "Tiruppur"
        ax.add_patch(Rectangle((bx + 9, by - 1), w, 2, fc=(GREY if stale else TEAL),
                               ec="none", hatch=("////" if stale else None)))
        ax.text(bx + 9.8 + w, by, (f"STALE FEED   {v}%" if stale else f"{v}%"),
                fontsize=5.5, va="center", color=(RED if stale else "#333"))
        by -= 4.0
    ax.text(50, 1.8, "Source: footfall counters, nightly extract", fontsize=5,
            color="#9AA0A8")

    if callouts:
        def dot(xx, yy, letter):
            ax.add_patch(plt.Circle((xx, yy), 1.7, fc=AMBER, ec="white", lw=0.8, zorder=5))
            ax.text(xx, yy, letter, fontsize=6, ha="center", va="center", color="white",
                    fontweight="bold", zorder=6)
        dot(-2.5, y_top - 4.5, "A")
        dot(102.5, 59, "B")
        dot(-2.5, ty - 7.2, "C")
        dot(102.5, ty - 9, "D")


def fig_dashboard_parts():
    fig, ax = plt.subplots(figsize=(6.6, 4.1))
    draw_dashboard(ax, banner=False, callouts=True)
    ax.set_xlim(-5, 105)
    save(fig, "fig1_1_dashboard_parts.pdf")


def fig_dashboard_hidden_disclosed():
    fig, axes = plt.subplots(2, 1, figsize=(6.6, 8.4))
    draw_dashboard(axes[0], banner=False)
    axes[0].set_title("(a) The screen as the regional manager saw it on 3 June",
                      loc="left", fontsize=8)
    draw_dashboard(axes[1], banner=True)
    axes[1].set_title("(b) The same screen with a data-provenance banner added",
                      loc="left", fontsize=8)
    fig.tight_layout(h_pad=2.0)
    save(fig, "fig1_2_dashboard_hidden_disclosed.pdf")


# ---------------------------------------------------------------------------
# Documentary strand (Figures 4.1 to 4.5)
# ---------------------------------------------------------------------------
def fig_fault_types():
    fig, ax = plt.subplots(figsize=(5.6, 3.0))
    cats = ["Model logic", "Consistency", "Completeness", "Accuracy"]
    silent = [4, 1, 1, 1]
    partial = [4, 0, 0, 0]
    visible = [0, 1, 0, 0]
    x = np.arange(len(cats))
    ax.bar(x, silent, color=NAVY, width=0.55, label="Silent at the point of use")
    ax.bar(x, partial, bottom=silent, color=TEAL, width=0.55, hatch="///",
           edgecolor="white", label="Partial at the point of use")
    ax.bar(x, visible, bottom=np.array(silent) + np.array(partial), color="white",
           edgecolor=NAVY, hatch="....", width=0.55, label="Visible at the point of use")
    for i in range(len(cats)):
        if silent[i]:
            ax.text(x[i], silent[i] / 2, str(silent[i]), ha="center", va="center",
                    color="white", fontsize=8, fontweight="bold")
        if partial[i]:
            ax.text(x[i], silent[i] + partial[i] / 2, str(partial[i]), ha="center",
                    va="center", color="white", fontsize=8, fontweight="bold")
        if visible[i]:
            ax.text(x[i], silent[i] + partial[i] + visible[i] / 2, str(visible[i]),
                    ha="center", va="center", color=NAVY, fontsize=8, fontweight="bold")
    ax.set_xticks(x)
    ax.set_xticklabels(cats)
    ax.set_ylabel("Number of cases")
    ax.set_xlabel("Type of defect in the system output")
    ax.set_ylim(0, 9)
    ax.legend(title="Was the defect visible on screen?", frameon=False, loc="upper right")
    save(fig, "fig4_1_fault_types.pdf")


CASES = [  # id, name, hours to notice, signal
    ("C7", "Knight Capital", 0.75, "Partial"),
    ("C2", "NATS flight planning", 4, "Partial"),
    ("C6", "TSB migration", 24, "Visible"),
    ("C8", "Ofqual grading", 4 * 24, "Partial"),
    ("C4", "PHE case undercount", 8 * 24, "Silent"),
    ("C11", "Zillow Offers", 6 * 30 * 24, "Partial"),
    ("C5", "Robodebt", 5 * 8760, "Silent"),
    ("C12", "Boeing 737 MAX (MCAS)", 6 * 8760, "Silent"),
    ("C3", "Citibank risk data", 7 * 8760, "Silent"),
    ("C9", "Dutch childcare benefits", 7 * 8760, "Silent"),
    ("C10", "Goldman Sachs reporting", 9 * 8760, "Silent"),
    ("C1", "Post Office Horizon", 16 * 8760, "Silent"),
]
TICKS = [1, 24, 24 * 7, 24 * 30, 8760, 87600]
TICKLAB = ["1 hour", "1 day", "1 week", "1 month", "1 year", "10 years"]
SIGCOL = {"Silent": NAVY, "Partial": TEAL, "Visible": "white"}


def fig_time_to_notice():
    fig, ax = plt.subplots(figsize=(6.0, 3.4))
    names = [f"{c[0]}  {c[1]}" for c in CASES]
    y = np.arange(len(CASES))[::-1]
    for yi, c in zip(y, CASES):
        col = SIGCOL[c[3]]
        ax.barh(yi, c[2], left=0.3, color=col, edgecolor=NAVY, height=0.6,
                hatch=("///" if c[3] == "Partial" else "...." if c[3] == "Visible" else None))
    ax.set_yticks(y)
    ax.set_yticklabels(names, fontsize=7)
    ax.set_xscale("log")
    ax.set_xticks(TICKS)
    ax.set_xticklabels(TICKLAB)
    ax.set_xlim(0.3, 200000)
    ax.set_xlabel("Time taken to notice the defect (logarithmic scale)")
    handles = [Rectangle((0, 0), 1, 1, fc=NAVY, ec=NAVY),
               Rectangle((0, 0), 1, 1, fc=TEAL, ec=NAVY, hatch="///"),
               Rectangle((0, 0), 1, 1, fc="white", ec=NAVY, hatch="....")]
    ax.legend(handles, ["Silent", "Partial", "Visible"], title="Signal at the point of use",
              frameon=False, loc="upper right")
    ax.grid(axis="x", color="#E3E6EA", lw=0.6)
    save(fig, "fig4_2_time_to_notice.pdf")


def fig_time_boxplot():
    fig, ax = plt.subplots(figsize=(3.6, 3.2))
    silent = [np.log10(c[2]) for c in CASES if c[3] == "Silent"]
    other = [np.log10(c[2]) for c in CASES if c[3] != "Silent"]
    bp = ax.boxplot([silent, other], widths=0.5, patch_artist=True,
                    medianprops=dict(color=AMBER, lw=1.6), showfliers=False)
    for patch, col in zip(bp["boxes"], [NAVY, TEAL]):
        patch.set_facecolor(col)
        patch.set_alpha(0.25)
        patch.set_edgecolor(col)
    rng = np.random.default_rng(3)
    for i, vals in enumerate([silent, other], start=1):
        ax.scatter(i + rng.uniform(-0.12, 0.12, len(vals)), vals, color=NAVY if i == 1 else TEAL,
                   s=14, zorder=3)
    ax.set_xticks([1, 2])
    ax.set_xticklabels(["Silent defect\n(n = 7)", "Partial or visible\n(n = 5)"])
    ax.set_yticks([np.log10(t) for t in TICKS])
    ax.set_yticklabels(TICKLAB)
    ax.set_ylabel("Time taken to notice (logarithmic scale)")
    ax.grid(axis="y", color="#E3E6EA", lw=0.6)
    save(fig, "fig4_3_time_boxplot.pdf")


def fig_challenge_outcome():
    fig, ax = plt.subplots(figsize=(5.4, 3.1))
    cats = ["Raised and\noverridden", "Raised, slow\nor ignored", "Raised and\nacted upon", "Never\nraised"]
    strong = [5, 0, 0, 0]
    moderate = [1, 1, 1, 1]
    weak = [1, 1, 0, 1]
    x = np.arange(4)
    ax.bar(x, strong, color=NAVY, width=0.55, label="Strong")
    ax.bar(x, moderate, bottom=strong, color=TEAL, width=0.55, hatch="///",
           edgecolor="white", label="Moderate")
    ax.bar(x, weak, bottom=np.array(strong) + np.array(moderate), color="white",
           edgecolor=NAVY, hatch="....", width=0.55, label="Weak")
    for i in range(4):
        base = 0
        for arr, colr in [(strong, "white"), (moderate, "white"), (weak, NAVY)]:
            if arr[i]:
                ax.text(x[i], base + arr[i] / 2, str(arr[i]), ha="center", va="center",
                        color=colr, fontsize=8, fontweight="bold")
            base += arr[i]
    ax.set_xticks(x)
    ax.set_xticklabels(cats)
    ax.set_ylabel("Number of cases")
    ax.set_xlabel("What happened when a person questioned the system output")
    ax.set_ylim(0, 8)
    ax.legend(title="Coded legitimacy asymmetry", frameon=False, loc="upper right")
    save(fig, "fig4_4_challenge_outcome.pdf")


def fig_coded_matrix():
    rows = [("C1 Post Office Horizon", "High", "High", "High", "Med"),
            ("C2 NATS flight planning", "Med", "Med", "Med", "Med"),
            ("C3 Citibank risk data", "High", "Med", "High", "Med"),
            ("C4 PHE case undercount", "High", "Med", "Low", "High"),
            ("C5 Robodebt", "High", "High", "High", "High"),
            ("C6 TSB migration", "Low", "Low", "High", "Med"),
            ("C7 Knight Capital", "Med", "Low", "Med", "High"),
            ("C8 Ofqual grading", "Med", "High", "High", "Med"),
            ("C9 Dutch childcare benefits", "High", "High", "High", "High"),
            ("C10 Goldman Sachs reporting", "High", "Low", "Low", "Med"),
            ("C11 Zillow Offers", "Med", "Med", "Low", "Low"),
            ("C12 Boeing 737 MAX (MCAS)", "High", "High", "High", "High")]
    cols = ["Defect was\nsilent", "Legitimacy\nasymmetry", "Challenge was\nsuppressed",
            "Control absent\nor bypassed"]
    colmap = {"High": NAVY, "Med": TEAL, "Low": LIGHT}
    txtcol = {"High": "white", "Med": "white", "Low": NAVY}
    fig, ax = plt.subplots(figsize=(5.6, 4.0))
    ax.set_xlim(0, 4)
    ax.set_ylim(0, len(rows))
    ax.axis("off")
    for i, r in enumerate(rows):
        y = len(rows) - 1 - i
        ax.text(-0.1, y + 0.5, r[0], ha="right", va="center", fontsize=7)
        for j, v in enumerate(r[1:]):
            ax.add_patch(Rectangle((j + 0.03, y + 0.06), 0.94, 0.88, fc=colmap[v],
                                   ec="white", lw=0.8))
            ax.text(j + 0.5, y + 0.5, v, ha="center", va="center", fontsize=6.5,
                    color=txtcol[v], fontweight="bold")
    for j, c in enumerate(cols):
        ax.text(j + 0.5, -0.25, c, ha="center", va="top", fontsize=7)
    save(fig, "fig4_5_coded_matrix.pdf")


# ---------------------------------------------------------------------------
# Experimental strand (Figures 4.6 to 4.11)
# ---------------------------------------------------------------------------
COND = ["Warning shown\nown judgement", "Warning shown\nauditable",
        "Fault hidden\nown judgement", "Fault hidden\nauditable"]
DEFER = [0.147, 0.237, 0.316, 0.421]
DEFENS = [0.575, 0.406, 0.380, 0.271]


def fig_conditions():
    fig, ax = plt.subplots(figsize=(5.8, 3.3))
    x = np.arange(4)
    w = 0.36
    ax.bar(x - w / 2, DEFER, w, color=NAVY, label="Followed the screen against the local evidence")
    ax.bar(x + w / 2, DEFENS, w, color=TEAL, hatch="///", edgecolor="white",
           label="Chose the defensible action")
    for i in range(4):
        ax.text(x[i] - w / 2, DEFER[i] + 0.012, f"{DEFER[i]:.3f}", ha="center", fontsize=7)
        ax.text(x[i] + w / 2, DEFENS[i] + 0.012, f"{DEFENS[i]:.3f}", ha="center", fontsize=7)
    ax.set_xticks(x)
    ax.set_xticklabels(COND)
    ax.set_ylabel("Proportion of decisions")
    ax.set_ylim(0, 0.68)
    ax.legend(frameon=False, loc="upper center", ncol=2, bbox_to_anchor=(0.5, 1.12))
    ax.grid(axis="y", color="#E3E6EA", lw=0.6)
    save(fig, "fig4_6_conditions.pdf")


def fig_forest():
    groups = [
        ("Followed the screen", [("Fault hidden (vs warning shown)", 2.69, 1.77, 4.08),
                                 ("Auditable framing (vs own judgement)", 1.81, 1.21, 2.70),
                                 ("Hidden \u00D7 auditable", 0.87, 0.50, 1.51)]),
        ("Defensible choice", [("Fault hidden", 0.45, 0.33, 0.63),
                               ("Auditable framing", 0.51, 0.36, 0.71)]),
        ("Intention to verify", [("Fault hidden", 0.47, 0.33, 0.66),
                                 ("Auditable framing", 0.98, 0.66, 1.45)]),
    ]
    fig, ax = plt.subplots(figsize=(6.2, 3.6))
    y = 0
    labels, ys = [], []
    for gname, items in groups:
        ax.text(0.21, y, gname, fontsize=7.5, style="italic", color=NAVY, va="center", ha="left")
        y -= 1
        for lab, orv, lo, hi in items:
            col = NAVY if (lo > 1 or hi < 1) else GREY
            ax.plot([lo, hi], [y, y], color=col, lw=1.4)
            ax.plot(orv, y, "o", color=col, ms=5)
            ax.text(5.6, y, f"{orv:.2f} [{lo:.2f}, {hi:.2f}]", fontsize=7, va="center")
            labels.append(lab)
            ys.append(y)
            y -= 1
        y -= 0.4
    ax.axvline(1, color=RED, lw=0.9, ls="--")
    ax.set_xscale("log")
    ax.set_xticks([0.25, 0.5, 1, 2, 4])
    ax.set_xticklabels(["0.25", "0.5", "1", "2", "4"])
    ax.set_xlim(0.2, 12)
    ax.set_yticks(ys)
    ax.set_yticklabels(labels, fontsize=7.5)
    ax.text(5.6, 0.9, "OR [95% CI]", fontsize=7, style="italic")
    ax.set_xlabel("Odds ratio (log scale), 95 per cent confidence interval")
    ax.grid(axis="x", color="#E3E6EA", lw=0.6)
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0)
    save(fig, "fig4_7_forest.pdf")


def fig_waterfall():
    fig, ax = plt.subplots(figsize=(5.8, 3.3))
    steps = [("Warning shown,\nown judgement", 0, 0.147, NAVY, None),
             ("+ fault hidden\n(detection failure)", 0.147, 0.169, AMBER, "///"),
             ("+ auditable framing\n(authority failure)", 0.316, 0.090, TEAL, "\\\\\\"),
             ("Fault hidden and\nauditable", 0, 0.421, NAVY, None)]
    for i, (lab, base, h, col, hatch) in enumerate(steps):
        ax.bar(i, h, bottom=base, color=col, alpha=(0.55 if i == 0 else 1), width=0.6,
               hatch=hatch, edgecolor="white")
        if i in (1, 2):
            ax.text(i, base + h + 0.012, f"+{h:.3f}", ha="center", fontsize=7.5, fontweight="bold")
        else:
            ax.text(i, base + h + 0.012, f"{h:.3f}", ha="center", fontsize=7.5, fontweight="bold")
    ax.plot([0.3, 0.7], [0.147, 0.147], color=GREY, lw=0.8, ls=":")
    ax.plot([1.3, 1.7], [0.316, 0.316], color=GREY, lw=0.8, ls=":")
    ax.plot([2.3, 2.7], [0.406, 0.406], color=GREY, lw=0.8, ls=":")
    ax.annotate("", xy=(3, 0.421), xytext=(3, 0.406),
                arrowprops=dict(arrowstyle="-", color="white", lw=1.5))
    ax.text(3, 0.36, "residual\n+0.015", ha="center", fontsize=6.8, color="white")
    ax.text(1, 0.365, "62% of the rise", ha="center", fontsize=7, color=AMBER)
    ax.text(2, 0.455, "33% of the rise", ha="center", fontsize=7, color=TEAL)
    ax.set_xticks(range(4))
    ax.set_xticklabels([s[0] for s in steps])
    ax.set_ylabel("Proportion following the screen")
    ax.set_ylim(0, 0.52)
    ax.grid(axis="y", color="#E3E6EA", lw=0.6)
    save(fig, "fig4_8_waterfall.pdf")


def fig_channels():
    fig, axes = plt.subplots(1, 2, figsize=(6.4, 2.8), sharey=True)
    measures = ["Followed the screen", "Intended to verify", "Mean confidence /7"]
    panels = [("(a) Hiding the fault", [(0.192, 0.368), (0.727, 0.556), (5.12 / 7, 5.41 / 7)], AMBER),
              ("(b) Making it auditable", [(0.231, 0.329), (0.642, 0.640), (5.31 / 7, 5.22 / 7)], TEAL)]
    for ax, (title, pairs, col) in zip(axes, panels):
        for i, (ref, trt) in enumerate(pairs):
            y = 2 - i
            ax.plot([ref, trt], [y, y], color="#C9CED6", lw=1.5, zorder=1)
            ax.plot(ref, y, "o", color="white", mec=GREY, ms=7, zorder=2)
            ax.plot(trt, y, "o", color=col, ms=7, zorder=3)
            d = trt - ref
            ax.text(trt, y + 0.25, f"{d:+.3f}", ha="center", fontsize=7, color=col, fontweight="bold")
        ax.set_yticks([2, 1, 0])
        ax.set_yticklabels(measures)
        ax.set_ylim(-0.6, 2.8)
        ax.set_xlim(0, 1)
        ax.set_xlabel("Proportion")
        ax.set_title(title, fontsize=8, color=NAVY, loc="left", pad=8)
        ax.grid(axis="x", color="#E3E6EA", lw=0.6)
    handles = [Line2D([], [], marker="o", color="white", mec=GREY, ms=6, ls=""),
               Line2D([], [], marker="o", color=AMBER, ms=6, ls=""),
               Line2D([], [], marker="o", color=TEAL, ms=6, ls="")]
    fig.legend(handles, ["reference level", "fault hidden", "auditable framing"],
               frameon=False, loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.06))
    fig.tight_layout()
    save(fig, "fig4_9_channels.pdf")


def fig_confidence():
    fig, ax = plt.subplots(figsize=(5.2, 3.0))
    x = np.arange(2)
    w = 0.32
    correct = [5.28, 5.64]
    wrong = [4.97, 5.29]
    ax.bar(x - w / 2, correct, w, color=[TEAL, AMBER], label="chose the defensible action")
    ax.bar(x + w / 2, wrong, w, color=[TEAL, AMBER], alpha=0.45, hatch="///", edgecolor="white",
           label="did not")
    for i in range(2):
        ax.text(x[i] - w / 2, correct[i] + 0.03, f"{correct[i]:.2f}", ha="center", fontsize=7.5)
        ax.text(x[i] + w / 2, wrong[i] + 0.03, f"{wrong[i]:.2f}", ha="center", fontsize=7.5)
    ax.axhline(5.28, color=NAVY, ls="--", lw=0.9)
    ax.text(1.55, 5.31, "confidence when correct,\nwarning shown", fontsize=6.5, color=NAVY)
    ax.set_xticks(x)
    ax.set_xticklabels(["Warning shown", "Fault hidden"])
    ax.set_ylabel("Mean stated confidence (1 to 7)")
    ax.set_ylim(4.4, 6.0)
    ax.set_xlim(-0.6, 2.1)
    handles = [Rectangle((0, 0), 1, 1, fc=NAVY), Rectangle((0, 0), 1, 1, fc=NAVY, alpha=0.45, hatch="///")]
    ax.legend(handles, ["chose the defensible action", "did not"], frameon=False, loc="upper left")
    ax.grid(axis="y", color="#E3E6EA", lw=0.6)
    save(fig, "fig4_10_confidence.pdf")


def fig_options():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(6.4, 2.9), gridspec_kw={"width_ratios": [1.6, 1]})
    k = np.arange(6)
    followed = [0.18, 0.28, 0.27, 0.12, 0.09, 0.06]
    notf = [0.14, 0.23, 0.30, 0.18, 0.10, 0.05]
    w = 0.38
    ax1.bar(k - w / 2, followed, w, color=NAVY, label="Followed the screen")
    ax1.bar(k + w / 2, notf, w, color=TEAL, hatch="///", edgecolor="white", label="Did not")
    ax1.set_xticks(k)
    ax1.set_xlabel("Distinct alternative actions named")
    ax1.set_ylabel("Proportion of responses")
    ax1.legend(frameon=False)
    ax1.grid(axis="y", color="#E3E6EA", lw=0.6)
    ax2.plot([0.80, 1.10], [0, 0], color=GREY, lw=1.6)
    ax2.plot(0.94, 0, "o", color=GREY, ms=6)
    ax2.axvline(1, color=RED, ls="--", lw=0.9)
    ax2.text(0.62, 0.30, "IRR 0.94 [0.80, 1.10]", ha="center", fontsize=7)
    ax2.text(1.02, -0.3, "no difference", fontsize=6.5, color=RED)
    ax2.set_xscale("log")
    ax2.set_xticks([0.5, 0.75, 1, 1.5])
    ax2.set_xticklabels(["0.5", "0.75", "1", "1.5"])
    ax2.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax2.xaxis.set_minor_locator(matplotlib.ticker.NullLocator())
    ax2.set_xlim(0.45, 1.7)
    ax2.set_ylim(-0.8, 0.8)
    ax2.set_yticks([0])
    ax2.set_yticklabels(["Followed the\nscreen"])
    ax2.set_xlabel("Incidence rate ratio (log scale)")
    ax2.spines["left"].set_visible(False)
    ax2.tick_params(axis="y", length=0)
    fig.tight_layout()
    save(fig, "fig4_11_options.pdf")


# ---------------------------------------------------------------------------
# Interview strand (Figures 4.12 and 4.13)
# ---------------------------------------------------------------------------
def fig_ratings():
    fig, ax = plt.subplots(figsize=(5.8, 3.0))
    items = [("R1  Go with the dashboard when it conflicts with ground knowledge", 31),
             ("R2  Can tell from the screen whether the data is current", 12),
             ("R3  A report-backed decision is easier to defend", 96),
             ("R4  Follow the dashboard, bad outcome: held responsible", 12),
             ("R5  Overrule the dashboard, bad outcome: held responsible", 92),
             ("R6  Disagreement with a report gets recorded", 31),
             ("R7  Someone must formally answer a concern before proceeding", 19),
             ("R8  Working from dashboards narrows the options considered", 69)]
    y = np.arange(len(items))[::-1]
    vals = [v for _, v in items]
    cols = [NAVY if v >= 60 else TEAL if v >= 30 else GREY for v in vals]
    ax.barh(y, vals, color=cols, height=0.62)
    for yi, v in zip(y, vals):
        ax.text(v + 1.5, yi, f"{v}%", va="center", fontsize=7.5)
    ax.set_yticks(y)
    ax.set_yticklabels([t for t, _ in items], fontsize=7)
    ax.set_xlim(0, 110)
    ax.set_xlabel("Percentage agreeing (6 or 7 on a seven-point scale), n = 26")
    ax.grid(axis="x", color="#E3E6EA", lw=0.6)
    save(fig, "fig4_12_ratings.pdf")


def fig_themes():
    fig, ax = plt.subplots(figsize=(6.2, 3.1))
    items = [("Describes the asymmetry as absent\nor reversed", 0.338, 0.111, "p = 0.006*"),
             ("Describes a standing forum obliged\nto answer the objection", 0.331, 0.125, "p = 0.018*"),
             ("Objection left no durable record", 0.125, 0.319, "p = 0.031*"),
             ("Disagreement voiced only verbally", 0.200, 0.458, "p = 0.013*"),
             ("Objection carried by rank, not\nby any mechanism", 0.204, 0.411, "p = 0.052")]
    y = np.arange(len(items))[::-1]
    for yi, (lab, absent, present, p) in zip(y, items):
        ax.plot([absent, present], [yi, yi], color="#C9CED6", lw=1.5, zorder=1)
        ax.plot(absent, yi, "o", color="white", mec=NAVY, ms=7, zorder=2)
        ax.plot(present, yi, "o", color=NAVY, ms=7, zorder=3)
        ax.text(0.53, yi, f"{present:.3f} vs {absent:.3f}   {p}", va="center", fontsize=7)
    ax.axvline(0.280, color=RED, ls="--", lw=0.9)
    ax.text(0.287, 4.45, "sample mean 0.280", fontsize=6.5, color=RED, va="center")
    ax.set_yticks(y)
    ax.set_yticklabels([i[0] for i in items], fontsize=7)
    ax.set_ylim(-0.6, 4.8)
    ax.set_xlim(0, 0.75)
    ax.set_xticks([0, 0.1, 0.2, 0.3, 0.4, 0.5])
    ax.set_xlabel("Mean proportion following the screen, in that participant's own experiment")
    handles = [Line2D([], [], marker="o", color="white", mec=NAVY, ms=6, ls=""),
               Line2D([], [], marker="o", color=NAVY, ms=6, ls="")]
    ax.legend(handles, ["theme absent", "theme present"], frameon=False, loc="upper center",
              ncol=2, bbox_to_anchor=(0.35, 1.13))
    ax.grid(axis="x", color="#E3E6EA", lw=0.6)
    save(fig, "fig4_13_themes.pdf")


if __name__ == "__main__":
    fig_dashboard_parts()
    fig_dashboard_hidden_disclosed()
    fig_fault_types()
    fig_time_to_notice()
    fig_time_boxplot()
    fig_challenge_outcome()
    fig_coded_matrix()
    fig_conditions()
    fig_forest()
    fig_waterfall()
    fig_channels()
    fig_confidence()
    fig_options()
    fig_ratings()
    fig_themes()
