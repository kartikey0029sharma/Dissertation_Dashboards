"""Word count of Chapters 1 to 6: body text, headings and box text.
Figures (with captions) and tables are excluded, as are LaTeX commands."""
import re, sys
files = ["chapters/ch1_introduction.tex","chapters/ch2_literature.tex","chapters/ch3_methodology.tex",
         "chapters/ch4_findings.tex","chapters/ch5_discussion.tex","chapters/ch6_conclusion.tex"]
total = 0
per = {}
for f in files:
    s = open(f).read()
    s = re.sub(r"(?<!\\)%.*", "", s)                                   # comments
    s = re.sub(r"\\begin\{figure\}.*?\\end\{figure\}", " ", s, flags=re.S)
    s = re.sub(r"\\begin\{table\}.*?\\end\{table\}", " ", s, flags=re.S)
    s = re.sub(r"\\begin\{tikzpicture\}.*?\\end\{tikzpicture\}", " ", s, flags=re.S)
    s = re.sub(r"\\(label|ref|cite|includegraphics)\{[^}]*\}", " ", s)
    s = re.sub(r"\\begin\{(thinkbox|keybox)\}\{([^}]*)\}", r" \2 ", s)  # keep box titles
    s = re.sub(r"\\(begin|end)\{[^}]*\}", " ", s)
    s = re.sub(r"\\[a-zA-Z]+\*?(\[[^\]]*\])?", " ", s)                 # commands
    s = re.sub(r"[{}\$~]", " ", s)
    words = [w for w in re.split(r"\s+", s) if re.search(r"[A-Za-z0-9]", w)]
    per[f] = len(words); total += len(words)
for f, n in per.items(): print(f"{n:6d}  {f}")
print(f"{total:6d}  TOTAL")
open("wordcount.txt","w").write(f"{total:,} ")
